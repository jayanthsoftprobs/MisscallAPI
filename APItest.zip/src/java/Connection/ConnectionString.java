/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Connection;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/**
 *
 * @author hp
 */
public class ConnectionString {
    
 public static String Url()
      {   
          String server="";
          String Database="";
           try
               {
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
               }
            catch(Exception e)
             {
                return e.getMessage();
             }    
             return "jdbc:sqlserver://bccsl.cwum3lppgbis.ap-south-1.rds.amazonaws.com;databaseName=E_coreBCCSL";  
            
      }           
      public static String Username()
      {     //return "postgres";  
          return "admin";
      }
      public static String Password()
      {       
          return "mccsu@12345";
      } 
    
}
