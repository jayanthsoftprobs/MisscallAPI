/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Connection;

/**
 *
 * @author hp
 */
public class Mess {
   	String name;

	public Mess(String name) {
		this.name = name;
	}

	public String toString() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}