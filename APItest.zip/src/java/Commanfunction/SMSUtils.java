/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Commanfunction;
import com.google.gson.Gson;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSetMetaData;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import Connection.ConnectionString;
import java.util.Calendar;
import Connection.Mess;
import com.sun.mail.imap.protocol.INTERNALDATE;
import java.net.InetAddress;
import java.sql.Timestamp;

/**
 *
 * @author user
 */
public class SMSUtils {
    
    public static Boolean smsGenrate(String phoneno,String Backcode,String username,String password,Returnvalue ReturnValue )
    {
        boolean valid=false;
         String MessageOrign="MissCall";
        
        try
        {   
//            phoneno="9845314234";
            InetAddress inetAddress = InetAddress. getLocalHost();
            String MessgaeOriginator= inetAddress.getHostAddress();
            Connection SConn;
            Connection Conn;
            double customer_id=0;
            String SMS="";
            Mess TransactionID;
            String HardcodeUsername="";
            String  HardcodePassword="";
            String Database="";
            String  Dusername="";
            String  DPSW="";
            String  Server="";
           
            Conn = DriverManager.getConnection(ConnectionString.Url(), ConnectionString.Username(), ConnectionString.Password());
        try
        {
            Statement stbankinfo = Conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String SQLbankinfo = "select * from Bankinfo where TollfreeNo='" + Backcode +"' and status=1";
            ResultSet rsbankinfo = stbankinfo.executeQuery(SQLbankinfo);
            boolean IsEmpty = !rsbankinfo.first();
            if (IsEmpty==true)
            {
                ReturnValue.setresponseText("Misscall Aleart not Activated");
                ReturnValue.setValid(false);
                ReturnValue.setresponseCode(2);
                ReturnValue.settransactionId("0");
                valid=false;  
            }
           else
            {
                HardcodeUsername=rsbankinfo.getString("username");
                HardcodePassword=rsbankinfo.getString("psw");
                Database=rsbankinfo.getString("DatabaseName");
                Dusername=rsbankinfo.getString("Dusername");
                DPSW=rsbankinfo.getString("Dpsw");
                Server=rsbankinfo.getString("serverName");
                if (HardcodeUsername.equals(username)==false)         
                {
                   ReturnValue.setresponseText("Invalid User Name ");
                   ReturnValue.setValid(false);
                   ReturnValue.setresponseCode(2);
                   ReturnValue.settransactionId("0");
                   valid=false;
                }
                if (HardcodePassword.equals(password)==false)        
                {
                  ReturnValue.setresponseText("Invalid password");
                  ReturnValue.setValid(false);
                  ReturnValue.setresponseCode(2);
                  ReturnValue.settransactionId("0");
                  valid=false;
                }
                List<Commanfunction.Returnvalue> ReturnValueList = new ArrayList<>();  
                String connection ="";
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                SConn = DriverManager.getConnection("jdbc:sqlserver://" + Server +";databaseName=" + Database,Dusername, DPSW);
                
                Statement stunreg = SConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                String SQLunreg = "select * from UnregMobileno where phoneNO='" + phoneno +"' and Status='true'";
                ResultSet rsunreg = stunreg.executeQuery(SQLunreg);
                boolean IsEmptyunreg = !rsunreg.first();
                if (IsEmptyunreg==false)
                {
                  ReturnValue.setresponseText("Mobile Number Not Registred");
                  ReturnValue.setValid(false);
                  ReturnValue.setresponseCode(2);
                  ReturnValue.settransactionId("0");
                  valid=false;
                  return  false;
                }
                Statement st = SConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                String SQL = "select * from vwGet_AC_Link_Custr_mast_Misscall where Account_type_Name in('SB','CA') and telephone_res='" + phoneno +"' and MissCallRequired='true'";
                ResultSet rs = st.executeQuery(SQL);
                boolean IsEmpty1 = !rs.first();
                if (IsEmpty1==true)
                {
                   SMS=BuildSMS(1001,"",SConn);  
                   insertunregmobilenumber("1",phoneno,SConn);
                }
               else
                {
                    customer_id=rs.getDouble("Customer_no");
//                    Calendar currenttime = Calendar.getInstance();
//                    java.sql.Timestamp GeneratedDateTime = new java.sql.Timestamp(currenttime.getTimeInMillis());
                    java.util.Date date = new java.util.Date();  
                    Timestamp ts=new Timestamp(date.getTime());  
                    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");  
//                    System.out.println(formatter.format(ts));
                    String smsstring=  rs.getString("Account_number")+ '|' +rs.getString("Acc_Closing_Balance")+"("+formatter.format(ts)+")";
                    SMS=BuildSMS(1000,smsstring,SConn);
                   
                }
            if(SMS.equals(""))
             {
                 SMS=("No message genrated");   
                 SMSUtils.InsertErrorLog(phoneno,"No message genrated",MessageOrign,MessgaeOriginator,Conn);
             }
           else
            {
               Mess mess = new Mess("");
               if(SMSUtils.insertsms(phoneno,SMS,MessageOrign,MessgaeOriginator,customer_id,SConn,mess)==true)
                {                    
                    valid=true;
                    ReturnValue.setresponseText("Sms Send Successfully");
                    ReturnValue.setValid(true);
                    ReturnValue.setresponseCode(200);
                    ReturnValue.settransactionId(mess.toString());     
                    
                }
           }                         
        }
        }
         catch(Exception E){                                 
                    valid=true;
                    ReturnValue.setresponseText(E.getMessage());
                    ReturnValue.setValid(true);
                    ReturnValue.setresponseCode(11);
                    ReturnValue.settransactionId("0");
                    SMSUtils.InsertErrorLog(phoneno,E.getMessage(),MessageOrign,MessgaeOriginator,Conn);
                }      
           }
         catch(Exception E){
                    valid=false;
                    ReturnValue.setresponseText(E.getMessage());
                    ReturnValue.setValid(false);
                    ReturnValue.setresponseCode(0);
                    ReturnValue.settransactionId("0");                      
         }
        return valid;
    }
    public static String BuildSMS(int SMSType,String ParameterList,Connection Conn){
        String MessageString;
        MessageString="";
        String ParameterListToken ="";
        int k ;
        int d;
        int i;
        BuildSMSreturn Ret = new BuildSMSreturn();
        try
        {
             Statement st= Conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);   
             String str="Select * from SMSFormats where SMSType ="+SMSType;
             ResultSet rs = st.executeQuery(str);
             boolean IsEmpty=!rs.first();
             if(IsEmpty==true){
                 Ret.setErrorMessage("No message genrated");
                 Ret.setSMSStringe("");
             }
             else
             {
                 try
                 {
                    ResultSetMetaData rsmd = rs.getMetaData();
                    d = rsmd.getColumnCount();
                    for(i=2;i<=d;i++)
                    {
                        if ((rs.getString(i)==null) || rs.getString(i).equals(""))
                        {
                            break;                           
                        }
                        else
                        {
                            k=ParameterList.indexOf("|");
                            ParameterListToken="";
                            if (k!=-1)
                            {
                                ParameterListToken=ParameterList.substring(0,Math.min(ParameterList.length(),k));
                                if(i==2)
                                {
                                     ParameterListToken=rs.getString(i)+" "+ParameterListToken;
                                     
                                }else
                                {
                                    ParameterListToken=" "+rs.getString(i)+" "+ParameterListToken;
                                    
                                }
                                ParameterList=ParameterList.substring(k+1);
                            }
                            else
                            {
                                ParameterListToken=""+rs.getString(i)+" "+ParameterList;
                                ParameterList=" ";
                         
                            }
                           if(Ret.getSMSString()==null)
                           {
                               Ret.setSMSStringe(ParameterListToken);
                           }
                           else
                           {
                            Ret.setSMSStringe(Ret.getSMSString()+ParameterListToken);
                           }
                        }
                    }
                    if(Ret.getSMSString().equals(""))
                    {
                        Ret.setErrorMessage("No message genrated");
                        Ret.setSMSStringe("");
                    }                    
                 }
                 catch(Exception E){
                    Ret.setErrorMessage("No message genrated");
                    Ret.setSMSStringe("");
                 }
             }             
        }
        catch(Exception E){
             Ret.setErrorMessage("No message genrated");
             Ret.setSMSStringe("");             
        }
        return Ret.getSMSString();
    }
    
    public static Object Generate_SMS(String data,Connection con)
    {
        
        Returnvalue Ret = new Returnvalue();
        List <Returnvalue> RetList =new ArrayList<Returnvalue>();
        Gson json = new Gson();
        GenerateSMS sv=json.fromJson(data,GenerateSMS.class);
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        String SMSString ="";
        try
        {
            String ParameterList=sv.getParameterList();
            int SMSType=sv.getSMSType();
            SMSString=BuildSMS(SMSType, ParameterList,con);
            Ret.setresponseText(SMSString);
            Ret.setValid(true);
            RetList.add(Ret);
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return new Gson().toJson(RetList);
    }
    public static boolean insertsms(String mobilenumber ,String SMSString,String MessageOrign,String MessgaeOriginator,double customerid , Connection con,Mess mess)
    {
       boolean valid=true;
       
       String SqlQuerryString ="Insert into sms_List (MsgData,PhoneNum,Delivarystatus,MessgaeOrigin,MessageGeneratedMachine,MessageGeneratedDateTime,customer_id ) Values(?,?,?,?,?,?,?)";
            try
            {
                 Calendar currenttime = Calendar.getInstance();
                 Date GeneratedDateTime = new Date((currenttime.getTime()).getTime());                
                 PreparedStatement cmdInsert = con.prepareStatement(SqlQuerryString,Statement.RETURN_GENERATED_KEYS);
                 cmdInsert.setString(1,SMSString);
                 cmdInsert.setString(2, mobilenumber);
                 cmdInsert.setInt(3, 0);
                 cmdInsert.setString(4, MessageOrign);
                 cmdInsert.setString(5, MessgaeOriginator);
                 cmdInsert.setDate(6, GeneratedDateTime);
                 cmdInsert.setDouble(7, customerid);             
                 cmdInsert.executeUpdate();
                 ResultSet rs = cmdInsert.getGeneratedKeys();
                 if(rs != null && rs.next()){
                     int id=0;
                     id=rs.getInt(1);
                    String s=String.valueOf(id);
                    mess.setName(s);
                }
                 valid=true;
            } 
            catch (Exception E)
            {
                valid=false;
            }       
       
        return valid;
    }

         public static boolean InsertErrorLog(String mobilenumber ,String ErrorDescription,String MessageOrign,String MessgaeOriginator,Connection con)
         {
         boolean valid=true;
         String SqlQuerryString = "Insert into SMSErrorLog (MobileNumber,SMsOrigin,SMSOriginator,ErrorDescription) values (?,?,?,?)";
            try
            {
                 PreparedStatement cmdInsert = con.prepareStatement(SqlQuerryString);
                 cmdInsert.setString(1, mobilenumber);
                 cmdInsert.setString(2, MessageOrign);
                 cmdInsert.setString(3, MessgaeOriginator);
                 cmdInsert.setString(4, ErrorDescription);
                 cmdInsert.execute();
                 valid=true;
            } 
            catch (Exception E)
            {
                valid=false;                
            }        
              return valid;
         }
 public static boolean insertunregmobilenumber(String Customer_id ,String phoneNO,Connection con)
         {
         boolean valid=true;
         String SqlQuerryString = "Insert into UnregMobileno (Customer_id,phoneNO,Status,Entrydate) values (?,?,?,?)";
            try
            {
                 Calendar currenttime = Calendar.getInstance();
                 Date GeneratedDateTime = new Date((currenttime.getTime()).getTime());
                 PreparedStatement cmdInsert = con.prepareStatement(SqlQuerryString);
                 cmdInsert.setString(1, Customer_id);
                 cmdInsert.setString(2, phoneNO);
                 cmdInsert.setInt(3, 1);
                 cmdInsert.setDate(4, GeneratedDateTime);
                 cmdInsert.execute();
                 valid=true;
            } 
            catch (Exception E)
            {
                valid=false;                
            }        
              return valid;
         }
}
    class SmsInsertreturn
    {
        private boolean success;
        private String result;

        public String getresult()
        {
        return result;
        }
        public void setresult(String result)
        {
        this.result=result;
        }
        public boolean getsuccess(){
        return success;
        }
        public void setsuccess(boolean success){
        this.success=success;
        }
    }
class BuildSMSreturn {
    private String SMSString;
    private String ErrorMessage;
     public String getSMSString()
    {
        return SMSString;
    }
    public void setSMSStringe(String SMSString)
    {
        this.SMSString=SMSString;
    }
    
      public String getErrorMessage()
    {
        return ErrorMessage;
    }
    public void setErrorMessage(String ErrorMessage)
    {
        this.ErrorMessage=ErrorMessage;
    }
    
}

class GenerateSMS
{
    private String AcShortName;
    private String MobileNumber;
    private double Amount;
    private double AvailableAmount;
    private String AccountNumber;
    private boolean Valid;
    private double CreditAmount;
    private double DebitAmount;
    private int SMSType;
    private String ParameterList;
    public String getAcShortName()
    {
        return AcShortName;
    }
    public void setAcShortName(String AcShortName)
    {
        this.AcShortName=AcShortName;
    }
    public String getMobileNumber()
    {
        return MobileNumber;
    }
    public void setMobileNumber(String MobileNumber)
    {
        this.MobileNumber=MobileNumber;
    }
    public double getAmount()
    {
        return Amount;
    }
    public void setAmount(double Amount)
    {
        this.Amount=Amount;
    }
    public double getAvailableAmount()
    {
        return AvailableAmount;
    }
    public void setAvailableAmount(double AvailableAmount)
    {
        this.AvailableAmount=AvailableAmount;
    }
    public String getAccountNumber()
    {
        return AccountNumber;
    }
    public void setAccountNumber(String AccountNumber)
    {
        this.AccountNumber=AccountNumber;
    }
    public boolean getValid()
    {
        return Valid;
    }
    public void setValid(boolean Valid)
    {
        this.Valid=Valid;
    }
    public double getCreditAmount()
    {
        return CreditAmount;
    }
    public void setCreditAmount(double CreditAmount)
    {
        this.CreditAmount=CreditAmount;
    }
    public double getDebitAmount()
    {
        return DebitAmount;
    }
    public void setDebitAmount(double DebitAmount)
    {
        this.DebitAmount=DebitAmount;
    }
    public int getSMSType()
    {
        return SMSType;
    }
    public void setSMSType(int SMSType)
    {
        this.SMSType=SMSType;
    }
    public String getParameterList()
    {
        return ParameterList;
    }
    public void setParameterList(String ParameterList)
    {
        this.ParameterList=ParameterList;
    }
}
