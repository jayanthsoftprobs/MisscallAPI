/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Commanfunction;

/**
 *
 * @author user
 */
public  class Returnvalue {
private boolean Valid;;
private String transactionId;  
private String responseText;
private int responseCode;



public double getresponseCode(){
    return responseCode;
}
public void setresponseCode(int responseCode){
    this.responseCode=responseCode;
}
public boolean  getValid() {
    return Valid;
}

public void setValid(boolean  Valid) {
    this.Valid = Valid;
}
public String getresponseText() {
    return responseText;
}

public void setresponseText(String responseText) {
    this.responseText = responseText;
}
public String gettransactionId() {
    return transactionId;
}

public void settransactionId(String transactionId) {
    this.transactionId = transactionId;
}

    }  
