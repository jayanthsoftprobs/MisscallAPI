/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package GetCustinfo;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import Connection.Mess;
/**
 * REST Web Service
 *
 * @author Administrator
 */

@Path("/Custinfo")
@Produces("application/json")
public class Customerinfo {
//    @POST 
//    @Path("info")
//    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
//    @Produces(MediaType.APPLICATION_JSON)
//    public Object Custinfo(@QueryParam(value = "mobileno") String mobileno,@QueryParam(value = "UserName") String UserName,@QueryParam(value = "Password") String Password,@QueryParam(value = "IPAdress") String IPAdress,@QueryParam(value = "BankCode") String BankCode)
//     {
//         boolean valid=true;
//        List<Commanfunction.Returnvalue> ReturnValueList = new ArrayList<>();
//        Commanfunction.Returnvalue ReturnValue = new Commanfunction.Returnvalue();
//         if(UserName==null)
//         {
//                ReturnValue.setresponseText("Please Enter User Name ");
//                ReturnValue.setValid(false);
//                ReturnValue.setresponseCode(2);
//                ReturnValue.settransactionId("0");
//                valid=false;
//          }
//         if(Password==null)
//         {
//                ReturnValue.setresponseText("Please Enter Password ");
//                ReturnValue.setValid(false);
//                ReturnValue.setresponseCode(2);
//                ReturnValue.settransactionId("0");
//                valid=false;
//          }
//          if(mobileno==null)
//         {
//                ReturnValue.setresponseText("Please Enter Phoneno ");
//                ReturnValue.setValid(false);
//                ReturnValue.setresponseCode(13);
//                ReturnValue.settransactionId("0");
//                valid=false;
//          }
//          if(valid==true)
//          {
//                ReturnValue.setresponseText("Infomation Send");
//                ReturnValue.setValid(true);
//                ReturnValue.setresponseCode(0);
//                ReturnValue.settransactionId("12");
//                valid=true;
//              
//          }
//      ReturnValueList.add(ReturnValue);      
//      return new Gson().toJson(ReturnValueList); //Just send back the JSON to the client. But user can do anything...
//}
   @GET
   @Produces("application/json")
   @Path("Customerinfo")
   public String Confirm2(@QueryParam(value = "mobileno") String mobileno,@QueryParam(value = "UserName") String UserName,@QueryParam(value ="Password") String Password,@QueryParam(value = "BankCode") String BankCode){
       Mess mess = new Mess("");       
         boolean valid=true;
         List<Commanfunction.Returnvalue> ReturnValueList = new ArrayList<>();
         Commanfunction.Returnvalue ReturnValue = new Commanfunction.Returnvalue();
         if(UserName==null)
         {
                ReturnValue.setresponseText("Please Enter User Name ");
                ReturnValue.setValid(false);
                ReturnValue.setresponseCode(2);
                ReturnValue.settransactionId("0");
                valid=false;
          }
         if(Password==null)
         {
                ReturnValue.setresponseText("Please Enter Password ");
                ReturnValue.setValid(false);
                ReturnValue.setresponseCode(2);
                ReturnValue.settransactionId("0");
                valid=false;
          }       
       
         if(mobileno==null || mobileno=="")
         {
                ReturnValue.setresponseText("Please Enter Phoneno ");
                ReturnValue.setValid(false);
                ReturnValue.setresponseCode(13);
                ReturnValue.settransactionId("0");
                valid=false;
          }
         if(BankCode==null||BankCode=="")
         {
                ReturnValue.setresponseText("Please Enter Back code");
                ReturnValue.setValid(false);
                ReturnValue.setresponseCode(11);
                ReturnValue.settransactionId("0");
                valid=false;
          }
          if(valid==true)
          {                
           Commanfunction.SMSUtils.smsGenrate(mobileno,BankCode,UserName,Password,ReturnValue);
          }
         ReturnValueList.add(ReturnValue); 
         return new Gson().toJson(ReturnValueList);  
      
   
    }
}
//Setting the post method url to the client
//WebTarget webTarget = client.target("http://localhost:8080/restfullab/api").path("book");
//
////Add key-value pair into the form object
//Form form = new Form();
//form.param("title", "RESTful Java with JAX-RS 2.0 ");
//form.param("author", "Bill Burke");
//
////Send the form object along with the post call
//Response response = webTarget.request().post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED));
//System.out.println("Respose code: " +  response.getStatus());
//System.out.println("Respose value: " + response.readEntity(String.class));